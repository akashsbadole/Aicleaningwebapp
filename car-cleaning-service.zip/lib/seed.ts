import { PrismaClient, UserRole, SubscriptionPlan, SubscriptionStatus, AppointmentStatus } from "@prisma/client"
import { hash } from "bcrypt"

const prisma = new PrismaClient()

async function main() {
  // Clear existing data
  await prisma.photo.deleteMany()
  await prisma.appointment.deleteMany()
  await prisma.vehicle.deleteMany()
  await prisma.user.deleteMany()
  await prisma.subscription.deleteMany()

  // Create admin user
  const adminPassword = await hash("admin123", 10)
  const admin = await prisma.user.create({
    data: {
      name: "Admin User",
      email: "admin@sparklewash.com",
      password: adminPassword,
      role: UserRole.ADMIN,
    },
  })

  // Create cleaners
  const cleanerPassword = await hash("cleaner123", 10)
  const cleaner1 = await prisma.user.create({
    data: {
      name: "John Smith",
      email: "john@sparklewash.com",
      password: cleanerPassword,
      role: UserRole.CLEANER,
    },
  })

  const cleaner2 = await prisma.user.create({
    data: {
      name: "Maria Garcia",
      email: "maria@sparklewash.com",
      password: cleanerPassword,
      role: UserRole.CLEANER,
    },
  })

  // Create subscriptions
  const monthlySubscription = await prisma.subscription.create({
    data: {
      plan: SubscriptionPlan.MONTHLY,
      status: SubscriptionStatus.ACTIVE,
      startDate: new Date(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
    },
  })

  const quarterlySubscription = await prisma.subscription.create({
    data: {
      plan: SubscriptionPlan.QUARTERLY,
      status: SubscriptionStatus.ACTIVE,
      startDate: new Date(),
      endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000), // 90 days from now
    },
  })

  const yearlySubscription = await prisma.subscription.create({
    data: {
      plan: SubscriptionPlan.YEARLY,
      status: SubscriptionStatus.ACTIVE,
      startDate: new Date(),
      endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 365 days from now
    },
  })

  // Create customers with vehicles and appointments
  const customerPassword = await hash("customer123", 10)

  // Customer 1 with monthly plan
  const customer1 = await prisma.user.create({
    data: {
      name: "Alex Johnson",
      email: "alex@example.com",
      password: customerPassword,
      role: UserRole.CUSTOMER,
      subscriptionId: monthlySubscription.id,
    },
  })

  const vehicle1 = await prisma.vehicle.create({
    data: {
      name: "Honda Civic",
      licensePlate: "KA01AB1234",
      type: "Sedan",
      color: "Blue",
      userId: customer1.id,
    },
  })

  // Create an upcoming appointment
  const appointment1 = await prisma.appointment.create({
    data: {
      date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      status: AppointmentStatus.ASSIGNED,
      services: JSON.stringify(["Exterior Wash", "Interior Vacuum", "Window Cleaning"]),
      customerId: customer1.id,
      cleanerId: cleaner1.id,
      vehicleId: vehicle1.id,
    },
  })

  // Customer 2 with quarterly plan
  const customer2 = await prisma.user.create({
    data: {
      name: "Sarah Williams",
      email: "sarah@example.com",
      password: customerPassword,
      role: UserRole.CUSTOMER,
      subscriptionId: quarterlySubscription.id,
    },
  })

  const vehicle2 = await prisma.vehicle.create({
    data: {
      name: "Toyota Corolla",
      licensePlate: "KA02CD5678",
      type: "Sedan",
      color: "Silver",
      userId: customer2.id,
    },
  })

  // Create an upcoming appointment
  const appointment2 = await prisma.appointment.create({
    data: {
      date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days from now
      status: AppointmentStatus.ASSIGNED,
      services: JSON.stringify(["Exterior Wash", "Interior Vacuum", "Window Cleaning", "Tire Shine"]),
      customerId: customer2.id,
      cleanerId: cleaner2.id,
      vehicleId: vehicle2.id,
    },
  })

  // Customer 3 with yearly plan
  const customer3 = await prisma.user.create({
    data: {
      name: "Michael Brown",
      email: "michael@example.com",
      password: customerPassword,
      role: UserRole.CUSTOMER,
      subscriptionId: yearlySubscription.id,
    },
  })

  const vehicle3 = await prisma.vehicle.create({
    data: {
      name: "Hyundai i20",
      licensePlate: "KA03EF9012",
      type: "Hatchback",
      color: "Red",
      userId: customer3.id,
    },
  })

  // Create a completed appointment
  const completedAppointment = await prisma.appointment.create({
    data: {
      date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
      status: AppointmentStatus.COMPLETED,
      services: JSON.stringify(["Exterior Wash", "Interior Vacuum", "Window Cleaning"]),
      customerId: customer3.id,
      cleanerId: cleaner1.id,
      vehicleId: vehicle3.id,
    },
  })

  // Add photos to the completed appointment
  await prisma.photo.createMany({
    data: [
      {
        url: "https://example.com/photos/car1-front.jpg",
        appointmentId: completedAppointment.id,
      },
      {
        url: "https://example.com/photos/car1-back.jpg",
        appointmentId: completedAppointment.id,
      },
    ],
  })

  console.log("Seed data created successfully")
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })

