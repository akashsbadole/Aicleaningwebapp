import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon, CarIcon, CreditCardIcon, HistoryIcon, ImageIcon } from "lucide-react"
import { AppointmentCard } from "@/components/appointment-card"
import { VehicleCard } from "@/components/vehicle-card"

export default function CustomerDashboard() {
  // This would normally be fetched from the database
  const upcomingAppointments = [
    {
      id: "1",
      date: "2025-04-02T10:00:00",
      status: "scheduled",
      vehicleName: "Honda Civic",
      cleanerName: "John Smith",
      services: ["Exterior Wash", "Interior Vacuum", "Window Cleaning"],
    },
    {
      id: "2",
      date: "2025-04-16T14:30:00",
      status: "scheduled",
      vehicleName: "Honda Civic",
      cleanerName: "Maria Garcia",
      services: ["Exterior Wash", "Interior Vacuum", "Window Cleaning", "Tire Shine"],
    },
  ]

  const pastAppointments = [
    {
      id: "3",
      date: "2025-03-19T09:00:00",
      status: "completed",
      vehicleName: "Honda Civic",
      cleanerName: "John Smith",
      services: ["Exterior Wash", "Interior Vacuum", "Window Cleaning"],
      photos: ["/placeholder.svg?height=200&width=300", "/placeholder.svg?height=200&width=300"],
    },
  ]

  const vehicles = [
    {
      id: "1",
      name: "Honda Civic",
      licensePlate: "KA01AB1234",
      type: "Sedan",
      color: "Blue",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-background border-b">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">SparkleWash</div>
          <nav className="flex items-center gap-4">
            <Button variant="ghost">Sign Out</Button>
          </nav>
        </div>
      </header>
      <main className="flex-1 container py-8">
        <h1 className="text-3xl font-bold mb-8">Customer Dashboard</h1>

        <Tabs defaultValue="appointments">
          <TabsList className="mb-8">
            <TabsTrigger value="appointments">
              <CalendarIcon className="h-4 w-4 mr-2" />
              Appointments
            </TabsTrigger>
            <TabsTrigger value="vehicles">
              <CarIcon className="h-4 w-4 mr-2" />
              Vehicles
            </TabsTrigger>
            <TabsTrigger value="subscription">
              <CreditCardIcon className="h-4 w-4 mr-2" />
              Subscription
            </TabsTrigger>
            <TabsTrigger value="history">
              <HistoryIcon className="h-4 w-4 mr-2" />
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="appointments" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Upcoming Appointments</h2>
              <Button>Schedule New Cleaning</Button>
            </div>

            {upcomingAppointments.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-6">
                {upcomingAppointments.map((appointment) => (
                  <AppointmentCard key={appointment.id} appointment={appointment} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p>No upcoming appointments. Schedule your first cleaning!</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="vehicles" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Your Vehicles</h2>
              <Button>Add New Vehicle</Button>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {vehicles.map((vehicle) => (
                <VehicleCard key={vehicle.id} vehicle={vehicle} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="subscription" className="space-y-6">
            <h2 className="text-2xl font-bold">Your Subscription</h2>

            <Card>
              <CardHeader>
                <CardTitle>Quarterly Plan</CardTitle>
                <CardDescription>Active until June 30, 2025</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Plan:</span>
                    <span className="font-medium">Quarterly (₹5,499 per quarter)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Next billing date:</span>
                    <span className="font-medium">July 1, 2025</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Payment method:</span>
                    <span className="font-medium">•••• •••• •••• 4242</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cleanings remaining this month:</span>
                    <span className="font-medium">1 of 2</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Change Plan</Button>
                <Button variant="destructive">Cancel Subscription</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <h2 className="text-2xl font-bold">Cleaning History</h2>

            {pastAppointments.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-6">
                {pastAppointments.map((appointment) => (
                  <Card key={appointment.id}>
                    <CardHeader>
                      <CardTitle className="flex justify-between">
                        <span>{new Date(appointment.date).toLocaleDateString()}</span>
                        <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">Completed</span>
                      </CardTitle>
                      <CardDescription>
                        {appointment.vehicleName} •{" "}
                        {new Date(appointment.date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm font-medium">Cleaner</p>
                          <p>{appointment.cleanerName}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Services</p>
                          <ul className="list-disc pl-5 text-sm">
                            {appointment.services.map((service, index) => (
                              <li key={index}>{service}</li>
                            ))}
                          </ul>
                        </div>
                        {appointment.photos && appointment.photos.length > 0 && (
                          <div>
                            <p className="text-sm font-medium flex items-center">
                              <ImageIcon className="h-4 w-4 mr-1" />
                              Photos
                            </p>
                            <div className="grid grid-cols-2 gap-2 mt-2">
                              {appointment.photos.map((photo, index) => (
                                <img
                                  key={index}
                                  src={photo || "/placeholder.svg"}
                                  alt={`Cleaning photo ${index + 1}`}
                                  className="rounded-md object-cover w-full h-24"
                                />
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p>No cleaning history yet.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>
      <footer className="bg-background border-t py-4">
        <div className="container text-center text-muted-foreground">
          <p>© 2025 SparkleWash. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

