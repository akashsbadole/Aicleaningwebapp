import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart3Icon, CalendarIcon, CarIcon, ClipboardListIcon, UsersIcon } from "lucide-react"
import { AdminAppointmentList } from "@/components/admin-appointment-list"
import { AdminUsersList } from "@/components/admin-users-list"
import { AdminDashboardStats } from "@/components/admin-dashboard-stats"

export default function AdminDashboard() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-background border-b">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">SparkleWash</div>
          <nav className="flex items-center gap-4">
            <Button variant="ghost">Sign Out</Button>
          </nav>
        </div>
      </header>
      <main className="flex-1 container py-8">
        <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>

        <Tabs defaultValue="overview">
          <TabsList className="mb-8">
            <TabsTrigger value="overview">
              <BarChart3Icon className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="appointments">
              <CalendarIcon className="h-4 w-4 mr-2" />
              Appointments
            </TabsTrigger>
            <TabsTrigger value="customers">
              <UsersIcon className="h-4 w-4 mr-2" />
              Customers
            </TabsTrigger>
            <TabsTrigger value="cleaners">
              <ClipboardListIcon className="h-4 w-4 mr-2" />
              Cleaners
            </TabsTrigger>
            <TabsTrigger value="vehicles">
              <CarIcon className="h-4 w-4 mr-2" />
              Vehicles
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <AdminDashboardStats />

            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Subscriptions</CardTitle>
                  <CardDescription>New customers in the last 30 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Alex Johnson</p>
                        <p className="text-sm text-muted-foreground">Quarterly Plan</p>
                      </div>
                      <span className="text-sm">Apr 1, 2025</span>
                    </li>
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Sarah Williams</p>
                        <p className="text-sm text-muted-foreground">Yearly Plan</p>
                      </div>
                      <span className="text-sm">Mar 28, 2025</span>
                    </li>
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Michael Brown</p>
                        <p className="text-sm text-muted-foreground">Monthly Plan</p>
                      </div>
                      <span className="text-sm">Mar 25, 2025</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Today's Appointments</CardTitle>
                  <CardDescription>Scheduled cleanings for today</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">10:00 AM</p>
                        <p className="text-sm">Alex Johnson • Honda Civic</p>
                        <p className="text-sm text-muted-foreground">Cleaner: John Smith</p>
                      </div>
                      <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">Assigned</span>
                    </li>
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">2:30 PM</p>
                        <p className="text-sm">Sarah Williams • Toyota Corolla</p>
                        <p className="text-sm text-muted-foreground">Cleaner: Maria Garcia</p>
                      </div>
                      <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">Assigned</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="appointments" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">All Appointments</h2>
              <Button>Create Appointment</Button>
            </div>

            <AdminAppointmentList />
          </TabsContent>

          <TabsContent value="customers" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Customers</h2>
              <Button>Add Customer</Button>
            </div>

            <AdminUsersList userType="customer" />
          </TabsContent>

          <TabsContent value="cleaners" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Cleaners</h2>
              <Button>Add Cleaner</Button>
            </div>

            <AdminUsersList userType="cleaner" />
          </TabsContent>

          <TabsContent value="vehicles" className="space-y-6">
            <h2 className="text-2xl font-bold">Registered Vehicles</h2>

            <Card>
              <CardContent className="p-0">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-4">Owner</th>
                      <th className="text-left p-4">Vehicle</th>
                      <th className="text-left p-4">License Plate</th>
                      <th className="text-left p-4">Type</th>
                      <th className="text-left p-4">Color</th>
                      <th className="text-left p-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="p-4">Alex Johnson</td>
                      <td className="p-4">Honda Civic</td>
                      <td className="p-4">KA01AB1234</td>
                      <td className="p-4">Sedan</td>
                      <td className="p-4">Blue</td>
                      <td className="p-4">
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-4">Sarah Williams</td>
                      <td className="p-4">Toyota Corolla</td>
                      <td className="p-4">KA02CD5678</td>
                      <td className="p-4">Sedan</td>
                      <td className="p-4">Silver</td>
                      <td className="p-4">
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </td>
                    </tr>
                    <tr>
                      <td className="p-4">Michael Brown</td>
                      <td className="p-4">Hyundai i20</td>
                      <td className="p-4">KA03EF9012</td>
                      <td className="p-4">Hatchback</td>
                      <td className="p-4">Red</td>
                      <td className="p-4">
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      <footer className="bg-background border-t py-4">
        <div className="container text-center text-muted-foreground">
          <p>© 2025 SparkleWash. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

