import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon, CheckCircleIcon, ClockIcon } from "lucide-react"
import { CleanerAppointmentCard } from "@/components/cleaner-appointment-card"

export default function CleanerDashboard() {
  // This would normally be fetched from the database
  const todayAppointments = [
    {
      id: "1",
      date: "2025-04-02T10:00:00",
      status: "assigned",
      customerName: "Alex Johnson",
      address: "123 Main St, Bangalore",
      vehicleName: "Honda Civic",
      vehicleDetails: {
        licensePlate: "KA01AB1234",
        type: "Sedan",
        color: "Blue",
      },
      services: ["Exterior Wash", "Interior Vacuum", "Window Cleaning"],
    },
  ]

  const upcomingAppointments = [
    {
      id: "2",
      date: "2025-04-16T14:30:00",
      status: "assigned",
      customerName: "Sarah Williams",
      address: "456 Park Ave, Bangalore",
      vehicleName: "Toyota Corolla",
      vehicleDetails: {
        licensePlate: "KA02CD5678",
        type: "Sedan",
        color: "Silver",
      },
      services: ["Exterior Wash", "Interior Vacuum", "Window Cleaning", "Tire Shine"],
    },
  ]

  const completedAppointments = [
    {
      id: "3",
      date: "2025-03-19T09:00:00",
      status: "completed",
      customerName: "Michael Brown",
      address: "789 Oak St, Bangalore",
      vehicleName: "Hyundai i20",
      vehicleDetails: {
        licensePlate: "KA03EF9012",
        type: "Hatchback",
        color: "Red",
      },
      services: ["Exterior Wash", "Interior Vacuum", "Window Cleaning"],
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-background border-b">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">SparkleWash</div>
          <nav className="flex items-center gap-4">
            <Button variant="ghost">Sign Out</Button>
          </nav>
        </div>
      </header>
      <main className="flex-1 container py-8">
        <h1 className="text-3xl font-bold mb-8">Cleaner Dashboard</h1>

        <Tabs defaultValue="today">
          <TabsList className="mb-8">
            <TabsTrigger value="today">
              <CalendarIcon className="h-4 w-4 mr-2" />
              Today
            </TabsTrigger>
            <TabsTrigger value="upcoming">
              <ClockIcon className="h-4 w-4 mr-2" />
              Upcoming
            </TabsTrigger>
            <TabsTrigger value="completed">
              <CheckCircleIcon className="h-4 w-4 mr-2" />
              Completed
            </TabsTrigger>
          </TabsList>

          <TabsContent value="today" className="space-y-6">
            <h2 className="text-2xl font-bold">Today's Appointments</h2>

            {todayAppointments.length > 0 ? (
              <div className="space-y-6">
                {todayAppointments.map((appointment) => (
                  <CleanerAppointmentCard key={appointment.id} appointment={appointment} showCompleteButton={true} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p>No appointments scheduled for today.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="upcoming" className="space-y-6">
            <h2 className="text-2xl font-bold">Upcoming Appointments</h2>

            {upcomingAppointments.length > 0 ? (
              <div className="space-y-6">
                {upcomingAppointments.map((appointment) => (
                  <CleanerAppointmentCard key={appointment.id} appointment={appointment} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p>No upcoming appointments scheduled.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="completed" className="space-y-6">
            <h2 className="text-2xl font-bold">Completed Appointments</h2>

            {completedAppointments.length > 0 ? (
              <div className="space-y-6">
                {completedAppointments.map((appointment) => (
                  <CleanerAppointmentCard key={appointment.id} appointment={appointment} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p>No completed appointments yet.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>
      <footer className="bg-background border-t py-4">
        <div className="container text-center text-muted-foreground">
          <p>© 2025 SparkleWash. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

