import Link from "next/link"
import { Button } from "@/components/ui/button"
import { PlanCard } from "@/components/plan-card"

export default function PricingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-background border-b">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="font-bold text-xl">
            SparkleWash
          </Link>
          <nav className="flex items-center gap-4">
            <Link href="/about">About</Link>
            <Link href="/pricing">Pricing</Link>
            <Link href="/contact">Contact</Link>
            <Link href="/sign-in">
              <Button variant="outline">Sign In</Button>
            </Link>
            <Link href="/sign-up">
              <Button>Sign Up</Button>
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="py-20">
          <div className="container">
            <h1 className="text-4xl font-bold text-center mb-4">Subscription Plans</h1>
            <p className="text-xl text-muted-foreground text-center max-w-2xl mx-auto mb-12">
              Choose the perfect plan for your car cleaning needs
            </p>
            <div className="grid md:grid-cols-3 gap-8">
              <PlanCard
                title="Monthly"
                price="₹1,999"
                period="per month"
                features={[
                  "2 cleanings per month",
                  "Interior vacuum",
                  "Exterior wash",
                  "Dashboard polish",
                  "Window cleaning",
                ]}
                popular={false}
                href="/sign-up?plan=monthly"
              />
              <PlanCard
                title="Quarterly"
                price="₹5,499"
                period="per quarter"
                features={[
                  "2 cleanings per month",
                  "Interior vacuum",
                  "Exterior wash",
                  "Dashboard polish",
                  "Window cleaning",
                  "Tire shine",
                  "10% discount on additional services",
                ]}
                popular={true}
                href="/sign-up?plan=quarterly"
              />
              <PlanCard
                title="Yearly"
                price="₹19,999"
                period="per year"
                features={[
                  "2 cleanings per month",
                  "Interior vacuum",
                  "Exterior wash",
                  "Dashboard polish",
                  "Window cleaning",
                  "Tire shine",
                  "Interior detailing (quarterly)",
                  "20% discount on additional services",
                ]}
                popular={false}
                href="/sign-up?plan=yearly"
              />
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h2>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div className="space-y-2">
                <h3 className="text-xl font-bold">How often can I schedule a cleaning?</h3>
                <p className="text-muted-foreground">
                  All plans include 2 cleanings per month. You can schedule additional cleanings at discounted rates.
                </p>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold">Can I cancel my subscription?</h3>
                <p className="text-muted-foreground">
                  Yes, you can cancel your subscription at any time. Refunds are processed according to our refund
                  policy.
                </p>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold">How do I schedule a cleaning?</h3>
                <p className="text-muted-foreground">
                  Once you subscribe, you can schedule cleanings through your customer dashboard.
                </p>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold">Do you provide cleaning supplies?</h3>
                <p className="text-muted-foreground">
                  Yes, our cleaners bring all necessary supplies and equipment for a thorough cleaning.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="bg-background border-t py-8">
        <div className="container text-center text-muted-foreground">
          <p>© 2025 SparkleWash. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

