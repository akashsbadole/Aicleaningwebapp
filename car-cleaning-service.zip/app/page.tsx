import Link from "next/link"
import { Button } from "@/components/ui/button"
import { PlanCard } from "@/components/plan-card"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-background border-b">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">SparkleWash</div>
          <nav className="flex items-center gap-4">
            <Link href="/about">About</Link>
            <Link href="/pricing">Pricing</Link>
            <Link href="/contact">Contact</Link>
            <Link href="/sign-in">
              <Button variant="outline">Sign In</Button>
            </Link>
            <Link href="/sign-up">
              <Button>Sign Up</Button>
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="py-20 bg-gradient-to-b from-background to-muted">
          <div className="container text-center space-y-6">
            <h1 className="text-5xl font-bold tracking-tight">Professional Car Cleaning Service</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Subscribe to our premium car cleaning service and enjoy a spotless vehicle all year round.
            </p>
            <div className="flex justify-center pt-4">
              <Link href="/pricing">
                <Button size="lg">View Plans</Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">Subscription Plans</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <PlanCard
                title="Monthly"
                price="₹1,999"
                period="per month"
                features={[
                  "2 cleanings per month",
                  "Interior vacuum",
                  "Exterior wash",
                  "Dashboard polish",
                  "Window cleaning",
                ]}
                popular={false}
                href="/sign-up?plan=monthly"
              />
              <PlanCard
                title="Quarterly"
                price="₹5,499"
                period="per quarter"
                features={[
                  "2 cleanings per month",
                  "Interior vacuum",
                  "Exterior wash",
                  "Dashboard polish",
                  "Window cleaning",
                  "Tire shine",
                  "10% discount on additional services",
                ]}
                popular={true}
                href="/sign-up?plan=quarterly"
              />
              <PlanCard
                title="Yearly"
                price="₹19,999"
                period="per year"
                features={[
                  "2 cleanings per month",
                  "Interior vacuum",
                  "Exterior wash",
                  "Dashboard polish",
                  "Window cleaning",
                  "Tire shine",
                  "Interior detailing (quarterly)",
                  "20% discount on additional services",
                ]}
                popular={false}
                href="/sign-up?plan=yearly"
              />
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div className="space-y-4">
                <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center mx-auto text-xl font-bold">
                  1
                </div>
                <h3 className="text-xl font-bold">Choose a Plan</h3>
                <p className="text-muted-foreground">Select a subscription plan that suits your needs and budget.</p>
              </div>
              <div className="space-y-4">
                <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center mx-auto text-xl font-bold">
                  2
                </div>
                <h3 className="text-xl font-bold">Schedule Service</h3>
                <p className="text-muted-foreground">
                  Book your cleaning appointments through our easy-to-use dashboard.
                </p>
              </div>
              <div className="space-y-4">
                <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center mx-auto text-xl font-bold">
                  3
                </div>
                <h3 className="text-xl font-bold">Enjoy a Clean Car</h3>
                <p className="text-muted-foreground">
                  Our professional cleaners will take care of your vehicle and send you photos after completion.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="bg-background border-t py-8">
        <div className="container text-center text-muted-foreground">
          <p>© 2025 SparkleWash. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

