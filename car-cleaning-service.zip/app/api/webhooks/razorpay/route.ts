import { NextResponse } from "next/server"
import crypto from "crypto"
import prisma from "@/lib/prisma"

// Verify Razorpay webhook signature
function verifyWebhookSignature(body: any, signature: string) {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET

  if (!secret) {
    throw new Error("RAZORPAY_WEBHOOK_SECRET is not defined")
  }

  const hmac = crypto.createHmac("sha256", secret)
  hmac.update(JSON.stringify(body))
  const generatedSignature = hmac.digest("hex")

  return crypto.timingSafeEqual(Buffer.from(generatedSignature), Buffer.from(signature))
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const signature = request.headers.get("x-razorpay-signature") || ""

    // Verify webhook signature
    if (!verifyWebhookSignature(body, signature)) {
      return NextResponse.json({ success: false, error: "Invalid signature" }, { status: 401 })
    }

    const { event, payload } = body

    // Handle subscription events
    if (event === "subscription.charged") {
      const { subscription } = payload

      // Update subscription status in database
      await prisma.subscription.update({
        where: {
          razorpaySubscriptionId: subscription.id,
        },
        data: {
          status: "ACTIVE",
          endDate: new Date(subscription.current_end * 1000),
        },
      })
    }

    if (event === "subscription.cancelled") {
      const { subscription } = payload

      // Update subscription status in database
      await prisma.subscription.update({
        where: {
          razorpaySubscriptionId: subscription.id,
        },
        data: {
          status: "CANCELLED",
        },
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Razorpay webhook error:", error)
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}

