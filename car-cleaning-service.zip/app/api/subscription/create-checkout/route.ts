import { NextResponse } from "next/server"
import Razorpay from "razorpay"
import prisma from "@/lib/prisma"
import { currentUser } from "@clerk/nextjs/server"

// Initialize Razorpay
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || "",
  key_secret: process.env.RAZORPAY_KEY_SECRET || "",
})

// Plan configurations
const PLANS = {
  MONTHLY: {
    amount: 199900, // ₹1,999 in paise
    interval: 1,
    period: "monthly",
  },
  QUARTERLY: {
    amount: 549900, // ₹5,499 in paise
    interval: 3,
    period: "monthly", // Razorpay uses "monthly" with interval 3 for quarterly
  },
  YEARLY: {
    amount: 1999900, // ₹19,999 in paise
    interval: 1,
    period: "yearly",
  },
}

export async function POST(request: Request) {
  try {
    const user = await currentUser()

    if (!user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const { plan } = await request.json()

    if (!plan || !PLANS[plan as keyof typeof PLANS]) {
      return NextResponse.json({ success: false, error: "Invalid plan" }, { status: 400 })
    }

    const planConfig = PLANS[plan as keyof typeof PLANS]

    // Create a Razorpay customer if not exists
    let razorpayCustomerId = ""
    const dbUser = await prisma.user.findUnique({
      where: { id: user.id },
      include: { subscription: true },
    })

    if (!dbUser) {
      return NextResponse.json({ success: false, error: "User not found" }, { status: 404 })
    }

    if (dbUser.subscription?.razorpayCustomerId) {
      razorpayCustomerId = dbUser.subscription.razorpayCustomerId
    } else {
      const customer = await razorpay.customers.create({
        name: user.firstName + " " + user.lastName,
        email: user.emailAddresses[0].emailAddress,
        contact: "", // Would need phone number from user
        notes: {
          userId: user.id,
        },
      })

      razorpayCustomerId = customer.id
    }

    // Create a subscription plan
    const subscription = await razorpay.subscriptions.create({
      plan_id: "", // You would create plans in Razorpay dashboard
      customer_id: razorpayCustomerId,
      total_count: 12, // Number of billing cycles
      quantity: 1,
      notes: {
        userId: user.id,
        plan: plan,
      },
    })

    // Create or update subscription in database
    const dbSubscription = await prisma.subscription.upsert({
      where: {
        id: dbUser.subscriptionId || "",
      },
      update: {
        plan: plan as any,
        razorpaySubscriptionId: subscription.id,
        razorpayCustomerId: razorpayCustomerId,
        startDate: new Date(),
        status: "ACTIVE",
      },
      create: {
        plan: plan as any,
        razorpaySubscriptionId: subscription.id,
        razorpayCustomerId: razorpayCustomerId,
        startDate: new Date(),
        status: "ACTIVE",
        users: {
          connect: {
            id: user.id,
          },
        },
      },
    })

    return NextResponse.json({
      success: true,
      data: {
        subscriptionId: subscription.id,
        key: process.env.RAZORPAY_KEY_ID,
      },
    })
  } catch (error) {
    console.error("Error creating subscription:", error)
    return NextResponse.json({ success: false, error: "Failed to create subscription" }, { status: 500 })
  }
}

