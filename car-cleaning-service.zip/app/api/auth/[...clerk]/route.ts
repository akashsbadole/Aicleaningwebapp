import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"

export async function POST(request: Request) {
  const { type, data } = await request.json()

  // Handle user creation in our database when a user signs up with Clerk
  if (type === "user.created") {
    const { id, email_addresses, first_name, last_name } = data

    try {
      // Create a new user in our database
      await prisma.user.create({
        data: {
          id: id,
          email: email_addresses[0].email_address,
          name: `${first_name || ""} ${last_name || ""}`.trim(),
          password: "", // We don't need to store passwords when using Clerk
          role: "CUSTOMER", // Default role
        },
      })

      return NextResponse.json({ success: true })
    } catch (error) {
      console.error("Error creating user in database:", error)
      return NextResponse.json({ success: false, error: "Failed to create user" }, { status: 500 })
    }
  }

  return NextResponse.json({ success: true })
}

