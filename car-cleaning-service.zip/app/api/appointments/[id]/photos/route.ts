import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { currentUser } from "@clerk/nextjs/server"
import { put } from "@vercel/blob"

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await currentUser()

    if (!user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const dbUser = await prisma.user.findUnique({
      where: { id: user.id },
    })

    if (!dbUser || dbUser.role !== "CLEANER") {
      return NextResponse.json({ success: false, error: "Only cleaners can upload photos" }, { status: 403 })
    }

    const appointmentId = params.id

    // Check if appointment exists and is assigned to this cleaner
    const appointment = await prisma.appointment.findFirst({
      where: {
        id: appointmentId,
        cleanerId: user.id,
      },
    })

    if (!appointment) {
      return NextResponse.json(
        { success: false, error: "Appointment not found or not assigned to you" },
        { status: 404 },
      )
    }

    const formData = await request.formData()
    const files = formData.getAll("photos") as File[]

    if (files.length === 0) {
      return NextResponse.json({ success: false, error: "No photos provided" }, { status: 400 })
    }

    const uploadPromises = files.map(async (file) => {
      const blob = await put(`appointments/${appointmentId}/${file.name}`, file, {
        access: "public",
      })

      return prisma.photo.create({
        data: {
          url: blob.url,
          appointmentId,
        },
      })
    })

    const photos = await Promise.all(uploadPromises)

    // Update appointment status to completed
    await prisma.appointment.update({
      where: { id: appointmentId },
      data: { status: "COMPLETED" },
    })

    // Send email notification to customer
    await sendCompletionEmail(appointmentId)

    return NextResponse.json({ success: true, data: photos })
  } catch (error) {
    console.error("Error uploading photos:", error)
    return NextResponse.json({ success: false, error: "Failed to upload photos" }, { status: 500 })
  }
}

async function sendCompletionEmail(appointmentId: string) {
  // Get appointment details with customer info
  const appointment = await prisma.appointment.findUnique({
    where: { id: appointmentId },
    include: {
      customer: true,
      vehicle: true,
      cleaner: true,
      photos: true,
    },
  })

  if (!appointment) return

  // This would be implemented with your email service provider
  // For example, using Resend, SendGrid, or Nodemailer
  console.log(`Sending completion email to ${appointment.customer.email}`)

  // Email implementation would go here
}

