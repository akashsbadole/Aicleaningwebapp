import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { currentUser } from "@clerk/nextjs/server"

export async function GET(request: Request) {
  try {
    const user = await currentUser()

    if (!user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const dbUser = await prisma.user.findUnique({
      where: { id: user.id },
    })

    if (!dbUser) {
      return NextResponse.json({ success: false, error: "User not found" }, { status: 404 })
    }

    let appointments

    // Different queries based on user role
    if (dbUser.role === "ADMIN") {
      // Admins can see all appointments
      appointments = await prisma.appointment.findMany({
        include: {
          customer: true,
          cleaner: true,
          vehicle: true,
          photos: true,
        },
        orderBy: {
          date: "asc",
        },
      })
    } else if (dbUser.role === "CUSTOMER") {
      // Customers can only see their own appointments
      appointments = await prisma.appointment.findMany({
        where: {
          customerId: user.id,
        },
        include: {
          cleaner: true,
          vehicle: true,
          photos: true,
        },
        orderBy: {
          date: "asc",
        },
      })
    } else if (dbUser.role === "CLEANER") {
      // Cleaners can only see appointments assigned to them
      appointments = await prisma.appointment.findMany({
        where: {
          cleanerId: user.id,
        },
        include: {
          customer: true,
          vehicle: true,
          photos: true,
        },
        orderBy: {
          date: "asc",
        },
      })
    }

    return NextResponse.json({ success: true, data: appointments })
  } catch (error) {
    console.error("Error fetching appointments:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch appointments" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const user = await currentUser()

    if (!user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const { date, vehicleId, services } = await request.json()

    // Create a new appointment
    const appointment = await prisma.appointment.create({
      data: {
        date: new Date(date),
        services: JSON.stringify(services),
        customerId: user.id,
        vehicleId,
      },
    })

    return NextResponse.json({ success: true, data: appointment })
  } catch (error) {
    console.error("Error creating appointment:", error)
    return NextResponse.json({ success: false, error: "Failed to create appointment" }, { status: 500 })
  }
}

