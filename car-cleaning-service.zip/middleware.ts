import { authMiddleware, clerkClient } from "@clerk/nextjs"
import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"

export default authMiddleware({
  publicRoutes: [
    "/",
    "/pricing",
    "/about",
    "/contact",
    "/sign-in",
    "/sign-up",
    "/api/webhooks/razorpay",
    "/api/webhooks/clerk",
  ],
  async afterAuth(auth, req) {
    // If the user is logged in and trying to access a protected route
    if (auth.userId && !auth.isPublicRoute) {
      try {
        // Check if user exists in our database
        const user = await prisma.user.findUnique({
          where: { id: auth.userId },
        })

        // If user doesn't exist in our database, create them
        if (!user) {
          const clerkUser = await clerkClient.users.getUser(auth.userId)

          await prisma.user.create({
            data: {
              id: auth.userId,
              email: clerkUser.emailAddresses[0].emailAddress,
              name: `${clerkUser.firstName || ""} ${clerkUser.lastName || ""}`.trim(),
              password: "", // We don't need to store passwords when using Clerk
              role: "CUSTOMER", // Default role
            },
          })
        }

        // Role-based access control
        if (user) {
          const path = req.nextUrl.pathname

          // Admin routes
          if (path.startsWith("/dashboard/admin") && user.role !== "ADMIN") {
            return NextResponse.redirect(new URL("/dashboard/customer", req.url))
          }

          // Cleaner routes
          if (path.startsWith("/dashboard/cleaner") && user.role !== "CLEANER") {
            if (user.role === "ADMIN") {
              return NextResponse.redirect(new URL("/dashboard/admin", req.url))
            } else {
              return NextResponse.redirect(new URL("/dashboard/customer", req.url))
            }
          }

          // Customer routes
          if (path.startsWith("/dashboard/customer") && user.role !== "CUSTOMER") {
            if (user.role === "ADMIN") {
              return NextResponse.redirect(new URL("/dashboard/admin", req.url))
            } else {
              return NextResponse.redirect(new URL("/dashboard/cleaner", req.url))
            }
          }
        }
      } catch (error) {
        console.error("Error in middleware:", error)
      }
    }

    return NextResponse.next()
  },
})

export const config = {
  matcher: ["/((?!.*\\..*|_next).*)", "/", "/(api|trpc)(.*)"],
}

