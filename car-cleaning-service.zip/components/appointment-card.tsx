import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CalendarIcon, ClockIcon, UserIcon } from "lucide-react"

interface Appointment {
  id: string
  date: string
  status: string
  vehicleName: string
  cleanerName: string
  services: string[]
  photos?: string[]
}

interface AppointmentCardProps {
  appointment: Appointment
}

export function AppointmentCard({ appointment }: AppointmentCardProps) {
  const appointmentDate = new Date(appointment.date)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex justify-between">
          <span>{appointmentDate.toLocaleDateString()}</span>
          <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">
            {appointment.status === "scheduled" ? "Scheduled" : "Completed"}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center">
            <CalendarIcon className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>
              {appointmentDate.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
            </span>
          </div>
          <div className="flex items-center">
            <ClockIcon className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>{appointmentDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
          </div>
          <div className="flex items-center">
            <UserIcon className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>Cleaner: {appointment.cleanerName}</span>
          </div>
          <div>
            <p className="text-sm font-medium mb-1">Vehicle</p>
            <p>{appointment.vehicleName}</p>
          </div>
          <div>
            <p className="text-sm font-medium mb-1">Services</p>
            <ul className="list-disc pl-5 text-sm">
              {appointment.services.map((service, index) => (
                <li key={index}>{service}</li>
              ))}
            </ul>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline">Reschedule</Button>
        <Button variant="destructive">Cancel</Button>
      </CardFooter>
    </Card>
  )
}

