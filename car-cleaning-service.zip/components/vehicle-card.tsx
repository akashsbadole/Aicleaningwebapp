import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CarIcon } from "lucide-react"

interface Vehicle {
  id: string
  name: string
  licensePlate: string
  type: string
  color: string
}

interface VehicleCardProps {
  vehicle: Vehicle
}

export function VehicleCard({ vehicle }: VehicleCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <CarIcon className="h-5 w-5 mr-2" />
          {vehicle.name}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-muted-foreground">License Plate:</span>
            <span>{vehicle.licensePlate}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Type:</span>
            <span>{vehicle.type}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Color:</span>
            <span>{vehicle.color}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline">Edit</Button>
        <Button variant="destructive">Remove</Button>
      </CardFooter>
    </Card>
  )
}

