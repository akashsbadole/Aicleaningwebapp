import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function AdminAppointmentList() {
  return (
    <Card>
      <CardContent className="p-0">
        <div className="p-4 border-b flex justify-between items-center">
          <div className="flex gap-4">
            <Select defaultValue="all">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="scheduled">Scheduled</SelectItem>
                <SelectItem value="assigned">Assigned</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="all">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Dates</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="tomorrow">Tomorrow</SelectItem>
                <SelectItem value="this-week">This Week</SelectItem>
                <SelectItem value="next-week">Next Week</SelectItem>
                <SelectItem value="this-month">This Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline">Export</Button>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left p-4">Date & Time</th>
              <th className="text-left p-4">Customer</th>
              <th className="text-left p-4">Vehicle</th>
              <th className="text-left p-4">Cleaner</th>
              <th className="text-left p-4">Status</th>
              <th className="text-left p-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b">
              <td className="p-4">Apr 2, 2025 10:00 AM</td>
              <td className="p-4">Alex Johnson</td>
              <td className="p-4">Honda Civic</td>
              <td className="p-4">John Smith</td>
              <td className="p-4">
                <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">Assigned</span>
              </td>
              <td className="p-4">
                <Button variant="ghost" size="sm">
                  View
                </Button>
              </td>
            </tr>
            <tr className="border-b">
              <td className="p-4">Apr 2, 2025 2:30 PM</td>
              <td className="p-4">Sarah Williams</td>
              <td className="p-4">Toyota Corolla</td>
              <td className="p-4">Maria Garcia</td>
              <td className="p-4">
                <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">Assigned</span>
              </td>
              <td className="p-4">
                <Button variant="ghost" size="sm">
                  View
                </Button>
              </td>
            </tr>
            <tr className="border-b">
              <td className="p-4">Mar 19, 2025 9:00 AM</td>
              <td className="p-4">Michael Brown</td>
              <td className="p-4">Hyundai i20</td>
              <td className="p-4">John Smith</td>
              <td className="p-4">
                <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">Completed</span>
              </td>
              <td className="p-4">
                <Button variant="ghost" size="sm">
                  View
                </Button>
              </td>
            </tr>
          </tbody>
        </table>
      </CardContent>
    </Card>
  )
}

