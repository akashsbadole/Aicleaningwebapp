import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CalendarIcon, ClockIcon, MapPinIcon, CarIcon, UploadIcon } from "lucide-react"

interface VehicleDetails {
  licensePlate: string
  type: string
  color: string
}

interface Appointment {
  id: string
  date: string
  status: string
  customerName: string
  address: string
  vehicleName: string
  vehicleDetails: VehicleDetails
  services: string[]
}

interface CleanerAppointmentCardProps {
  appointment: Appointment
  showCompleteButton?: boolean
}

export function CleanerAppointmentCard({ appointment, showCompleteButton = false }: CleanerAppointmentCardProps) {
  const appointmentDate = new Date(appointment.date)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex justify-between">
          <span>{appointmentDate.toLocaleDateString()}</span>
          <span
            className={`text-sm px-2 py-1 rounded ${
              appointment.status === "completed" ? "bg-green-100 text-green-800" : "bg-blue-100 text-blue-800"
            }`}
          >
            {appointment.status === "completed" ? "Completed" : "Assigned"}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center">
            <CalendarIcon className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>
              {appointmentDate.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
            </span>
          </div>
          <div className="flex items-center">
            <ClockIcon className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>{appointmentDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
          </div>
          <div>
            <p className="text-sm font-medium mb-1">Customer</p>
            <p>{appointment.customerName}</p>
          </div>
          <div className="flex items-start">
            <MapPinIcon className="h-4 w-4 mr-2 text-muted-foreground mt-0.5" />
            <span>{appointment.address}</span>
          </div>
          <div>
            <p className="text-sm font-medium mb-1 flex items-center">
              <CarIcon className="h-4 w-4 mr-1" />
              Vehicle Details
            </p>
            <div className="pl-6 space-y-1">
              <p>{appointment.vehicleName}</p>
              <p className="text-sm text-muted-foreground">
                {appointment.vehicleDetails.color} • {appointment.vehicleDetails.type} •{" "}
                {appointment.vehicleDetails.licensePlate}
              </p>
            </div>
          </div>
          <div>
            <p className="text-sm font-medium mb-1">Services</p>
            <ul className="list-disc pl-5 text-sm">
              {appointment.services.map((service, index) => (
                <li key={index}>{service}</li>
              ))}
            </ul>
          </div>
        </div>
      </CardContent>
      {showCompleteButton && (
        <CardFooter>
          <Button className="w-full">
            <UploadIcon className="h-4 w-4 mr-2" />
            Complete & Upload Photos
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}

