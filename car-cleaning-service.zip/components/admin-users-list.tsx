import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

interface AdminUsersListProps {
  userType: "customer" | "cleaner"
}

export function AdminUsersList({ userType }: AdminUsersListProps) {
  // This would normally be fetched from the database
  const customers = [
    {
      id: "1",
      name: "Alex Johnson",
      email: "alex@example.com",
      phone: "+91 98765 43210",
      plan: "Quarterly",
      joinDate: "Mar 15, 2025",
    },
    {
      id: "2",
      name: "Sarah Williams",
      email: "sarah@example.com",
      phone: "+91 98765 12345",
      plan: "Yearly",
      joinDate: "Feb 28, 2025",
    },
    {
      id: "3",
      name: "Michael Brown",
      email: "michael@example.com",
      phone: "+91 98765 67890",
      plan: "Monthly",
      joinDate: "Jan 10, 2025",
    },
  ]

  const cleaners = [
    {
      id: "1",
      name: "John Smith",
      email: "john@sparklewash.com",
      phone: "+91 98765 11111",
      status: "Active",
      joinDate: "Jan 5, 2025",
    },
    {
      id: "2",
      name: "Maria Garcia",
      email: "maria@sparklewash.com",
      phone: "+91 98765 22222",
      status: "Active",
      joinDate: "Feb 10, 2025",
    },
    {
      id: "3",
      name: "David Lee",
      email: "david@sparklewash.com",
      phone: "+91 98765 33333",
      status: "On Leave",
      joinDate: "Mar 1, 2025",
    },
  ]

  const users = userType === "customer" ? customers : cleaners

  return (
    <Card>
      <CardContent className="p-0">
        <div className="p-4 border-b flex justify-between items-center">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder={`Search ${userType}s...`} className="w-[300px] pl-8" />
          </div>
          <Button variant="outline">Export</Button>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left p-4">Name</th>
              <th className="text-left p-4">Email</th>
              <th className="text-left p-4">Phone</th>
              {userType === "customer" ? (
                <th className="text-left p-4">Plan</th>
              ) : (
                <th className="text-left p-4">Status</th>
              )}
              <th className="text-left p-4">Join Date</th>
              <th className="text-left p-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} className="border-b">
                <td className="p-4">{user.name}</td>
                <td className="p-4">{user.email}</td>
                <td className="p-4">{user.phone}</td>
                {userType === "customer" ? (
                  <td className="p-4">{(user as any).plan}</td>
                ) : (
                  <td className="p-4">
                    <span
                      className={`text-sm px-2 py-1 rounded ${
                        (user as any).status === "Active"
                          ? "bg-green-100 text-green-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {(user as any).status}
                    </span>
                  </td>
                )}
                <td className="p-4">{user.joinDate}</td>
                <td className="p-4">
                  <Button variant="ghost" size="sm">
                    View
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardContent>
    </Card>
  )
}

